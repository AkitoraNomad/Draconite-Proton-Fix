# 《龙晶》Linux 启动修复

这个社区补丁适用于在 Linux 上通过 Steam 启动《龙晶》（App ID `4337080`），并遇到 `WORKER_PRIORITY_FAILED (OS 87.0)` 的玩家。安装包支持 x86-64 Linux，包含已编译的 Wine DLL 和对应源码。Steam Deck 和 Flatpak 路径已纳入安装脚本，实际游戏启动在原生 Steam 的 Arch Linux 上验证。

## 安装

1. 完整解压 ZIP，在解压出来的 `Draconite-Proton-Fix` 文件夹中打开终端。Steam Deck 可在桌面模式下操作。
2. 运行 `bash install.sh`。脚本会复用已有的原版 GE-Proton 11-12 x86-64，或从 GE 的 GitHub 发布页下载约 541 MiB 的原版包，再安装一份独立的兼容工具。首次安装请预留约 2.5 GiB 空间。 [GE-Proton 11-12 发布页](https://github.com/GloriousEggroll/proton-ge-custom/releases/tag/GE-Proton11-12)
3. 完全退出并重新打开 Steam。右键《龙晶》→ 属性 → 兼容性，勾选「强制使用特定的 Steam Play 兼容工具」，选择 **`Draconite-Proton-GE-11-12`**，然后用「玩 龙晶」启动。

如果同时安装了原生 Steam 和 Flatpak Steam，用 `--steam-root` 指定要修复的版本。可用 `--archive` 指定已经下载好的官方 GE-Proton 压缩包。

```bash
bash install.sh --steam-root "$HOME/.var/app/com.valvesoftware.Steam/data/Steam"
bash install.sh --archive /path/to/GE-Proton11-12-x86_64.tar.gz
```

## 恢复原来的兼容工具

在《龙晶》的兼容性设置里切回原来的 Proton。要移除这个工具，可退出 Steam 并删除安装脚本显示的 `Draconite-Proton-GE-11-12` 目录。

## 修了什么

游戏自检在读取文件前请求 Windows 的线程后台模式。原版 Proton 返回错误 87，游戏因此中止校验。这个补丁让校验线程在后台模式下以较低的 CPU 优先级运行，退出时恢复原值。文件校验仍由游戏执行。安装脚本仅在 Steam 的 `compatibilitytools.d` 中安装新工具，保留现有 Proton、游戏文件和存档。 [微软接口文档](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setthreadpriority)

在《龙晶》Build `26593543` 上通过 Steam 默认启动选项验证可进入主菜单。此补丁实现后台模式的 CPU 优先级行为，Windows 后台模式还涉及 I/O 和内存优先级。

## 源码

`source/` 包含 Valve Wine 的对应源码快照、GE 的版本信息补丁、本补丁、构建脚本和 LGPL 许可文本。维护者可运行 `bash source/build.sh` 重建 DLL，所用工具包括 GCC、MinGW-w64（x86-64 和 i686）、GNU Make、Autoconf、Bison、Flex 和 Wine 配置所需的开发依赖。基础 Wine 提交为 `fda79a585939fb7512dc220a11249f9ffe825fcf`。 [Valve Wine 源码](https://github.com/ValveSoftware/wine/tree/fda79a585939fb7512dc220a11249f9ffe825fcf)
